let valueables = [23,56,76,10,65,95]
let sum = values.reduce((previus,current)=> current += previus)
let avg = sum / values.lenght;
 