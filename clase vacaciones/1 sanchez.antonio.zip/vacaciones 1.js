x= "escaja un número"
//con base a eso, lo que se hará es que el usuario tiene que dar "x" números del 1 al 10
//la idea es que el usuario nos de unos cuantos números del 1 al 10, la idea es que podamos calcular el promedio con estos
float ;n1; n2; n3;
String ;N 
N = "nombre del usuario"
n1 = "escriba un número"
n2 = "escriba un número"
n3 = "escriba un número"
cout <<"ingrese un número"<<endl;
cout <<"N"<<endl;
cout <<"ingrese la primera nota"<< endl;
cin << n1;
cout <<"ingrese la segunda nota"<< endl;
cin << n2;
cout <<"ingrese la tercera nota"<< endl;
cin << n3;

P= (n1+n2+n3)/3
cout <<"nombre del usuario" << N <<endl;
cout <<"N" << endl
cout << "promedio obtenido es:" << P <<endl;
 