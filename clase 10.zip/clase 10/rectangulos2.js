let ancho;
let alto;
do {
    ancho = parseFloat(prompt("Ingrese el ancho"));
  } while (isNaN(ancho) || ancho < 1);

  do {
    alto = parseFloat(prompt("Ingrese el alto"));
  } while (isNaN(alto) || alto < 1);

  let norte;
  
  for(i=1; i<=1; i++);
  { if (j=1); (j<=N); (j++);

  }
  {
    if(i==1 || i==N || j==1 || j==N)
    {
        printf("*");
    }
    else
    {
        printf(" ");
    }
}
printf("\n");

    return 0;

Salida