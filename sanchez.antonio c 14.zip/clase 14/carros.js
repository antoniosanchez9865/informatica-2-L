let carro = 
{    marca = mercedes 
     [modelo] = a200
     [year]= 2020
     [kilometraje] = 4.000
}
let carro1 = {
     marca = BMW
     [modelo] = serie8
     [Year] = 2020
     [kilometraje] = 4300
}
let carro2 = {
     marca = mercedes
     [modelo] = clase [G]
     [Year] = 2020
     [kilometraje] = 4120
}

let carro3= {
     marca= mercedes 
     [modelo] = AMG
     [year] = 2020
     [kilometraje] = 3850
}

let carro4 = {
     marca = BMW
     [modelo] = X6
     [year] = 2020
     [kilometraje] = 4050
}
let X6 
{
     [marca] = BMW
     [year] = 2020
     [kilometraje] =4050
}
let tot = [carro]+[carro1]+[carro2]+[carro3]+[carro4]     
let Santiago = nombre [Santiago]
{
     nombre [Santiago]
     edad = [16]
     colegio = [Formarte]
     tot =  [carro]+[carro1]+[carro2]+[carro3]+[carro4]
}

