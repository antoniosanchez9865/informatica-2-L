let n = "escriba un numero"
let m = "escriba un numero"
console.log (n+m2)
{if (n<0)
    return 1
    console.log (`Calculando ${n} + factorial (${n + 1}2)`)

    if (m<0) 
    return 1
} 