let r = "escriba un número"
//ese número es para el radio de la circunferencia
function volesfera(r){
    if(r<=1) return 1
    else{
        console.log(`(Calculando ${r})3 * Math.PI * 4/3 `);
        //esto es para calcular el volumen de la esfera 
        //V= 4/3* Math.PI * (r)3
        return n * factorial (r - 1)
    }

}