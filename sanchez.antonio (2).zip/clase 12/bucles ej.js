let r = "escriba un número"
//ese número es para el radio de la circunferencia
function  areacir(r){
    if (r<=1) return 1
    else{
        console.log(`(Calculando ${r})2 * Math.PI `);
        return n * factorial (r - 1)
    }
}
Math.PI