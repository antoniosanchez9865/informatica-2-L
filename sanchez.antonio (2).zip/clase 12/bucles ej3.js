let x = "escriba una palabra"
let y = "escriba una palabra"
 (x<y)
 if (x<y)
  //si la primera palabra es más larga la función string irá con ese plabra
 {String(x)
    if (y<x)
    //si la segunda palabra es más larga la función string irá con ese plabra
    {String (y)
    }
 }