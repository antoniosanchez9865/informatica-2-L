let a = "escriba un numero"
let b = "escriba un numero"
b<a
//b simpre tiene que ser mayor que a 
function max (n)
{if (b<a) return 1
else{
    if (a<b) 
    finish 
    //a no puede ser mayor que b porque si no el porgrama no funcionaría
}
}


