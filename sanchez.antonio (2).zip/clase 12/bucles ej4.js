let x = "escriba un numero"
let y = "escriba un numero"
(x<y)
if (x<y)
if (x<y)
 //si la primera palabra es más larga la función string irá con ese plabra
{String(x)
   if (y<x)
   //si la segunda palabra es más larga la función string irá con ese plabra
   {String (y)
   }
   if (x<y) print 
   //si x es mayor que y se debe imprimir la primera palabra
   if (y<x) print 
   //si y es mayor que x se debe imprimir la segunda palabra
}